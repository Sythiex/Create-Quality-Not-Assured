# Larion: Below

A datapack restoring vanilla noise caves to Larion 4.3.0 on Minecraft 1.21.1. Larion's existing cave features and settings remain unchanged.

## Versions

- **Larion Below:** the regular cave restoration.
- **Larion Below Less Surface Caves:** the variant with roughly 50% fewer caves above sea level.

Enable only one version at a time.

## Caves Added

- **Vanilla noodle caves:** Lower sampling limit extended from Y -60 to Y -124. Shape, thickness, and the upper sampling limit of Y 320 are unchanged.
- **Vanilla 2D spaghetti caves:** Target elevations below Y 0 are moved twice as deep—for example, Y -32 becomes Y -64. Targets at or above Y 0 and tunnel thickness are unchanged.
- **Vanilla cave entrances and 3D spaghetti caves:** Restored with no changes to their vanilla settings.

## Compatibility

This pack overrides only `larion:overworld/final_density`. Restored functions use `larion_below:` so Larion's unused Minecraft noodle and spaghetti overrides cannot substitute their tuning. Noise settings and carvers are not replaced.

Other packs overriding this final density, its dependencies, or Overworld noise settings are not compatible.

## Credits and Changes

Larion World Generation by Badgerson / ViciousBadger: https://github.com/ViciousBadger/larion-world-generation

The modified Larion final-density definition retains its original branches and adds vanilla surface entrances, underground entrances/2D spaghetti inside the pillar stage, and a final noodle minimum.

Vanilla cave definitions derive from Mojang's Minecraft Java 1.21.1 data. Noodles change only their lower sampling bounds; 2D spaghetti changes only the approved elevation remapping and lower gradient endpoint; cave dependency IDs are relocated. Mojang/Microsoft retain rights to Minecraft material; the Larion license does not relicense that material. This project is not an official Minecraft or Larion release.
