Create LTAB Lootr Compat v4.1.0-1.21.1

For Minecraft 1.21.1, Create Let The Adventure Begin 4.1.0, and Lootr.
Converts 17 prefilled loot containers across 7 structure templates by replacing
stored inventories with guaranteed loot tables. Original item IDs, quantities,
enchantments, and Create package contents are preserved. Inventory slot layout
is randomized by loot generation. Existing loot tables are unchanged.

Coverage:
- cave_ruins/cave_ruin1: 6 decorated pots
- dungeon/room4: 1 barrel
- not__junos_house: 4 barrels
- plains/dirt_hut: 1 chest and 2 decorated pots
- railroad: 1 barrel, including its complete gift package
- the_bunker: 1 chest
- normal_oak_house: 1 chest (currently unused by the mod's structure pools)

Excluded:
- big_windmill chest: connected to a hopper; preserve machine operation.
- Empty storage, furnishings, and machinery inventories.
- Six suspicious-sand blocks using missing create_ltab:rare_loot: already
  eligible for Lootr; selecting replacement loot is outside this conversion.
