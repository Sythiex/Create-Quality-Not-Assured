# Prefilled IDAS loot: Lootr compatibility

Scanned all 259 structure templates in the installed IDAS 1.13.7 JAR, including optional variants and leftover pieces. The scan found 3,428 saved item-bearing records; this includes air placeholders and decorative/functional inventories, not just treasure containers. No previously unused structure or optional integration is enabled by this pack.

## Converted

351 fixed loot tables replace the saved `Items` lists in 350 blocks and one entity across 72 templates: 205 barrels, 118 Quark chests, 25 Quark trapped chests, two vanilla chests, and one uncoupled chest minecart. Counts are template occurrences, not the number of containers in each generated instance of a structure.

Each original stack contributes a guaranteed, single-entry loot pool. This preserves the saved items and total quantities instead of substituting generic random dungeon loot. Normal loot-table filling can shuffle slots and split stacks; original slot layout is not preserved. Double-chest halves retain their own contents, so the combined item total is preserved when Lootr converts them.

| Structure family | Converted sources across its templates |
| --- | ---: |
| `abandoned_vineyard` | 9 |
| `abandonedhouse` | 11 |
| `ancient_mines` | 17 |
| `apothecary_abode` | 10 |
| `bazaar` | 7 |
| `bearclaw_inn` | 9 |
| `beekeepers_house` | 14 |
| `brickhouse` | 6 |
| `castle` | 26 |
| `collectors_museum` | 16 |
| `cottage` | 1 |
| `desert_market` | 12 |
| `farmhouse` | 5 |
| `fishermans_lodge` | 16 |
| `haunted_manor` | 10 |
| `hermits_hollow` | 1 |
| `hunters_cabin` | 12 |
| `labyrinth` | 19 |
| `pillager_fortress` | 65 |
| `redhorn_guild` | 5 |
| `ruins_of_the_deep` | 3 |
| `sunken_ship` | 15 |
| `tinkers_citadel` | 2 |
| `tinkers_workshop` | 13 |
| `treetop_tavern` | 18 |
| `wacky_wares` | 1 |
| `winter_wagon` | 14 |
| `wizard_tower` | 14 |

## Safety exceptions among supported containers

| Template | Local position | Reason left unchanged |
| --- | --- | --- |
| `abandoned_vineyard/abandoned_vineyard_bottom.nbt` | `(10, 4, 6)` | Contains 82 potions in oversized saved stacks; ordinary loot-table filling cannot preserve this in 27 slots. |
| `ancient_mines/ancient_mines_entrance.nbt` | `Create-coupled minecart` | Create-coupled minecart; conversion could lose coupling/assembly behavior. |
| `castle/castle2.nbt` | `(10, 0, 35)` | Barrel receives items from the Create chute directly above it. |
| `pumpkin_cafe/pumpkin_cafe.nbt` | `(42, 0, 36)` | Egg barrel receives items from a hopper aimed into it. |
| `train_ruins/train_ruins.nbt` | `(18, 5, 17)` | Conservative exclusion: storage inside the Create piston/train assembly. |

The Ancient Mines room9 chest minecart has no coupling and is converted. The entrance minecart has an explicit Create coupling and is preserved. The train barrel is a conservative exclusion because its location is part of a Create piston/train build; this is not a claim that conversion was observed breaking it in-game.

Nearby redstone alone is not treated as proof that an inventory is functional. The other supported containers have no nearby comparator or connected item-transfer block identified in the template audit. The Bearclaw Inn chests sit beside a downward chute, rather than above/below it; they are converted. Trapped chests keep their original block states and use Quark/Lootr trapped-chest support.

## Other sources deliberately preserved

- Appearance preserved as requested: 160 sacks, 25 cabinets, 43 urns, 65 presents/trapped presents, and other decorative/display blocks. This Lootr version cannot turn them into personal loot inventories without replacing their block or adding code support.
- Functional/protected inventories: dispensers, droppers, hoppers, furnaces, brewing stands, campfires, and locked safes. Their supplies, mechanisms, ownership, and locks remain intact.
- The original 1,183 suspicious-sand/gravel records contained `minecraft:air`, not actual prefilled loot. A subsequent cleanup removes those invalid `item` fields, plus 14 equivalents in Better Archaeology blocks. IDAS still assigns archaeology tables through processors where configured; no new treasure sources are added. See [air-item-cleanup.json](air-item-cleanup.json) and the README.
- 58 vanilla item/glow frames are already covered by the installed Lootr structure-frame option, subject to its exclusions (including maps). Quark glass frames and other displays retain their original behavior.
- Dropped items and other saved decorative/entity contents are not replaced with containers.

## Missing integration items and metadata

Tables use one-item tags with `required: false`. If an original item exists, its original quantity is generated. If it is unavailable, that entry produces no item instead of invalidating the whole table. This also retains compatibility with optional integration items if their exact IDs become available later. The pack does not invent substitutes for missing modded items. The vanilla `minecraft:grass` ID is updated to `minecraft:short_grass`, matching the vanilla item data-fixer rename.

The first in-game reload exposed an additional registry dependency that optional item tags cannot protect: potion types inside `minecraft:potion_contents`. Three unavailable Alex's Mobs potions caused the two Pillager Fortress tables at `(23, 47, 22)` and `(24, 47, 22)` in `pillager_fortress3.nbt` to fail parsing. The `bug_pheromones`, `long_lava_vision`, and `knockback_resistance` potion entries have now been omitted, preserving all other entries in those tables. The audit JSON records the three omissions. Revisit this exclusion if Alex's Mobs becomes available; it is specific to the current modlist.

Legacy potion, enchantment, durability, name, banner-pattern, and Quark item metadata is translated to 1.21.1 components. Written-book text/authors/titles and existing enchantment components are retained. Quark component names and the seed-pouch stored-item codec were checked against the installed Quark JAR. One legacy empty quiver capability inventory is represented by the item's default empty inventory.

Optional item tags protect missing item references; components still target the current installed modlist (including Quark and Supplementaries). Re-audit this pack if those mods are removed or IDAS is updated.

## Validation and rebuilding

- Every changed block/entity was decoded before and after editing to verify that only `Items` was removed and `LootTable` added. The surrounding decompressed template bytes are retained verbatim.
- Existing IDAS connector and loot-reference repairs are composed into the same NBT overrides.
- Updated independent validation checked all 351 tables against 4,129 retained original stacks, including 36 written books, 77 potion stacks, and 41 enchanted stacks; it explicitly accounts for the three omitted unavailable potion stacks. Item totals, metadata, optional tags, installed enchantment resources, and all pack JSON passed.
- The 2026-09-13 05:55 resource reload confirmed pack discovery and reported exactly the two potion-related `idas_fixes` parsing errors above. No other `idas_fixes` parsing errors were logged. A subsequent reload is still needed to verify the correction; individual loot rolls and Lootr conversion have not been observed directly.

Build scripts are in `local/datapack-builds/` relative to the Minecraft instance. The baseline audit is `idas-prefilled-audit.json`; do not regenerate it from the already-converted merged pack before rebuilding. It records the original inventories used for validation. `idas_convert_prefilled.py` can be rerun against the current pack and refuses to overwrite unrecognized template edits. After rerunning either earlier NBT-fix script, rerun the converter so those templates regain their prefilled-loot conversions. Then run `idas_verify_prefilled.py`.

Full per-source decisions: [prefilled-loot-audit.json](prefilled-loot-audit.json). Original inventory contents and nearby machinery: `local/datapack-builds/idas-prefilled-audit.json`.

References: [Lootr](https://modrinth.com/mod/lootr), [NeoForge 1.21.1 loot-table entries](https://docs.neoforged.net/docs/1.21.1/resources/server/loottables/), [NeoForge loot functions](https://docs.neoforged.net/docs/1.21.1/resources/server/loottables/lootfunctions/).
