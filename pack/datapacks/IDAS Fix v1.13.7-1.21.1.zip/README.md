# IDAS Fixes

Datapack for Minecraft 1.21.1 and IDAS 1.13.7.

## Prefilled loot and Lootr

Converts **350 prefilled chest/barrel blocks and one chest minecart across 72 templates** into loot-table sources. Each of the 351 new tables reproduces that container's saved items and quantities, including journals, potion types, enchantments, names, and durability. Lootr can give each player these fixed contents; slot placement and stack arrangement may change.

The existing structure palettes are preserved. Quark supplies native Lootr variants for its chests. Sacks, cabinets, urns, presents, and decorative inventories remain unchanged, as requested, to preserve their appearance and behavior. Functional inventories and five specific unsafe/uncertain conversion candidates are also preserved.

See [PREFILLED-LOOT.md](PREFILLED-LOOT.md) for the coverage, exceptions, and validation details. [prefilled-loot-audit.json](prefilled-loot-audit.json) lists the decision for every audited saved item source, with template and position.

These changes affect **newly generated or newly placed structures only**. Reopen the world from the title screen (or create a new world) to load the pack changes via Paxi. Already generated containers are not rewritten. In-game confirmation of Lootr conversion remains to be done.

## Biome tag cleanup

- Replaces IDAS's four BOP/BYG biome tags with optional biome entries (`required: false`).
- Defines the three tag names referenced by the lumber camp structures as aliases of the existing tags.
- Uses `replace: true` so the original required biome entries do not survive tag merging.

Without the referenced biome mods, these tags resolve to empty sets and the corresponding lumber camps have no eligible biomes. If the exact referenced biome IDs are available, their original memberships are preserved.

| Tag overridden or added | Biome or alias |
| --- | --- |
| `idas:has_structure/bopmohogany_biomes` | Optional `biomesoplenty:rainforest` |
| `idas:has_structure/bopredwood_biomes` | Optional `biomesoplenty:redwood_forest` |
| `idas:has_structure/byg_redwood_biomes` | Optional `byg:redwood_thicket` |
| `idas:has_structure/bygmohogany_biomes` | Optional `byg:tropical_rainforest` |
| `idas:has_structure/bopmahogany_biomes` | Alias of `idas:has_structure/bopmohogany_biomes` |
| `idas:has_structure/bygmahogany_biomes` | Alias of `idas:has_structure/bygmohogany_biomes` |
| `idas:has_structure/bygredwood_biomes` | Alias of `idas:has_structure/byg_redwood_biomes` |

## Loot path fixes

Five compatibility loot tables forward stale IDs to existing IDAS tables. Each wrapper rolls the target table once, retaining its loot definitions. These loot fixes do not edit the templates. All IDs below use the `idas:` namespace.

| Stale ID supplied by this pack | Existing target |
| --- | --- |
| `chests/minescreate` | `chests/ancient_mines/minescreate` |
| `chests/mineshall` | `chests/ancient_mines/mineshall` |
| `chests/brickhouse_windmill` | `chests/brickhouse/brickhouse_windmill` |
| `chests/labyrinth` | `chests/labyrinth/labyrinth` |
| `chests/pillagerjail` | `chests/pillager_fortress/pillager_jail` |

The first four preserve the filename and restore the missing subfolder. The fifth also restores the underscore in `pillager_jail` and targets the jail table belonging to the structure that references it.

These aliases apply to newly generated containers and existing containers that still have an unresolved loot-table reference. They do not refill containers whose loot has already been generated or consumed.

## Loot fixes within individual templates

Four additional NBT overrides repair seven container references using loot tables belonging to each structure. These changes only replace the specified containers' `LootTable` strings; their other data and the surrounding builds remain unchanged. All loot IDs below have the prefix `idas:chests/`.

| Template | Old suffix | Replacement suffix | Containers |
| --- | --- | --- | --- |
| `abandonedhouse/abandonedhouse2.nbt` | `idasbasic` | `abandonedhouse/abandonedhouse` | 1 |
| `abandonedhouse/abandonedhouse2.nbt` | `idaslibrary` | `abandonedhouse/abandonedhouse_library` | 2 |
| `hunters_cabin/hunters_cabin.nbt` | `idaslibrary` | `hunters_cabin/hunters_cabin_library` | 2 |
| `pillager_fortress/pillager_fortress1.nbt` | `idasbasic` | `pillager_fortress/pillager_basic` | 1 |
| `labyrinth/floor2.nbt` | `throne` | `labyrinth/labyrinth_tomb` | 1 |

The Labyrinth choice follows the parallel Ice and Fire template: its chest at the exact same local position `(14, 5, 41)` uses `if_labyrinth_tomb`. The normal template therefore uses the existing normal tomb table. The other structures already use their corresponding destination tables elsewhere in their templates.

The original loot definitions, including their enchanted-book entries, are retained. No global aliases are added for `idasbasic`, `idaslibrary`, or `throne`. These template overrides affect newly placed structures; they do not rewrite container references in existing world chunks.

Build/verification script: `local/datapack-builds/idas_fix_template_loot.py`, relative to the Minecraft instance folder. It validates every replacement table and container position, checks the Labyrinth variant evidence, and verifies that the decompressed templates differ only in the seven intended `LootTable` fields.

## Structure piece path fix

Adds `idas:desert_pyramid/desert_pyramid_villager` as a template pool matching the existing `idas:desert_pyramid/villager` pool. The alias preserves its template, processor list, projection, weight, and fallback. This supplies the pool requested by two jigsaws in `desert_pyramid_entrance2.nbt`.

This fixes the missing pool for future generation; it does not insert missing pieces into structures already generated.

## Haunted Manor attachment fix

Corrects two jigsaw `target` fields in the existing `haunted_manor/haunted_manor1.nbt` override, preserving its prefilled-loot conversions and all other template data:

| Local block position | Old target | Correct target |
| --- | --- | --- |
| `(46, 47, 0)` | `minecraft:haunted_manor2` | `idas:haunted_manor2` |
| `(46, 47, 1)` | `minecraft:haunted_manor4` | `idas:haunted_manor4` |

The corrected targets match the receiving connectors in pieces 2 and 4. Piece 3 attaches through piece 2. All four templates and pools already exist; the Ice and Fire variant already has matching targets.

Build/verification script: `local/datapack-builds/idas_fix_haunted_manor.py`. It verifies that only the two target fields change, checks the three attachment links and orientations, and reads back the saved output. The prefilled-loot converter preserves this repair when rebuilding. In-game placement verification is pending.

Reopen the world from the title screen to load this repair through Paxi. It affects newly generated or newly placed manors; it does not restore pieces in existing world chunks.

## Leftover connector cleanup

Overrides two structure templates from IDAS 1.13.7, changing only one jigsaw's `pool` string in each to `minecraft:empty`:

| Template | Local block position | Removed pool reference |
| --- | --- | --- |
| `ancient_mines/ancient_mines_entrance.nbt` | `(0, 0, 0)` | `idas:ancient_mines/ancient_mines_entrance2` |
| `desert_pyramid/desert_pyramid_cave1.nbt` | `(36, 8, 21)` | `idas:desert_pyramid/desert_pyramid_cave2` |

Both connectors retain `final_state: minecraft:air`. All other block states, block entity data, entities, and connector settings are preserved.

The Ancient Mines entrance keeps its working connection at `(20, 0, 24)` to room1, through which all nine rooms and nine halls remain reachable. The unused corner connector no longer requests a nonexistent pool.

The Desert Pyramid caves remain unused leftovers: no pools are added to enable them. Cave1's stale outgoing pool is disabled; cave2 itself needs no override because its pool references (`minecraft:empty` and `idas:desert_pyramid/main`) already exist.

These changes apply to future template placement and do not modify existing world chunks. The build/verification script is `local/datapack-builds/idas_cleanup_connectors.py`, relative to the Minecraft instance folder. It checks the exact source jigsaw positions and verifies that each decompressed NBT changes only the selected pool field.

## Invalid air-item cleanup

Removes 1,197 invalid `item: {id: "minecraft:air", ...}` fields across 42 structure templates: 1,183 in vanilla suspicious sand/gravel and 14 in Better Archaeology blocks. These are empty-item placeholders, not real rewards. The block states, archaeology processors, loot-table assignments, other NBT fields, and existing datapack repairs are preserved.

Coverage includes Desert Pyramid (882), Dig Site (187), Labyrinth (120), and Desert Ruins (8), counting template occurrences. Unused and optional templates are cleaned without enabling their generation. This removes this particular source of invalid-air-item errors from future placement; errors originating in other mods can still appear.

The build/verification script is `local/datapack-builds/idas_cleanup_air_items.py`. It checks every affected template's complete decoded NBT against an expected copy with only the audited `item` fields removed, then verifies the saved output. [air-item-cleanup.json](air-item-cleanup.json) records every cleaned position. Run this script last after any earlier builder; the prefilled-loot converter also preserves the cleanup on rebuild.

Reopen the world from the title screen to load the changes through Paxi. These template overrides affect newly placed structures and do not rewrite existing chunks. In-game confirmation of the cleaned templates is still pending.

## Abandoned Lighthouse height

Overrides `idas:abandoned_lighthouse`, changing only `start_height.absolute` from `0` to `1`. This raises future placements by one block relative to `WORLD_SURFACE_WG`, compensating for the pool element's one-block ground offset. All other placement settings, the template, and its processors are preserved. Reopen the world from the title screen to load the change; existing lighthouses are not moved. The override was compared against the installed IDAS JAR to verify that only the height changed; in-game placement verification is pending.

## Issues remaining

- The first in-game reload caught three unavailable Alex's Mobs potion types in two new Pillager Fortress tables. These entries have now been omitted; the other loot is preserved. The corrected tables need another resource/world reload. See `PREFILLED-LOOT.md` for details.
- The unused BOP Labyrinth variant (`labyrinth/bopfloor2.nbt`) still references `idas:chests/throne`. The four template loot fixes above cover the currently generating structures in this instance.
- The Dread Citadel 5/12 missing pools are not simple aliases of existing pools and remain unmodified.
- Optional Ice and Fire / Ars Nouveau loot and spawner load errors are unchanged.
- IDAS still has Guard Villagers entities that are skipped when that mod is absent. The audited archaeology air-item placeholders have now been removed; invalid-air-item warnings from other data can still appear.
